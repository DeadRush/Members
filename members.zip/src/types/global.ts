export type ProfileType = {
  imgUrl: string;
  name: string;
  mail: string;
  rating: number;
};
